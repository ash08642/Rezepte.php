<footer>
        <span class="name">AHMAD ABEER AHSAN</span>
        <span class="mail">aa.ahsan@stud.fh-sm.de</span>
</footer>