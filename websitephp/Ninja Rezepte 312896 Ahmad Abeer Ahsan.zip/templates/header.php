<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rezepte</title>
    <link rel="stylesheet" href="style.css">
    <script src="index.js"></script>
</head>

<body background="pexels-ray-piedra-1565982.jpg">
    <div class="background"></div>
    <header">
        <nav>
            <div class = logo>
                <h4>Ninja Rezepte</h4>
            </div>
            <ul class="nav-links">
                <li>
                    <a class="recipie" href="index.php">Rezepte</a>
                </li>
                <li>
                    <a class="konto" href="hinzufugen.php">Rezepte Hinzüfugen</a>
                </li>
                
            </ul>
        </nav>
    </header>