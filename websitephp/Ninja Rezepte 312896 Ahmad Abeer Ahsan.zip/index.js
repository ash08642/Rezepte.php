function breakfastSelect(){
    var rd = document.getElementById("breakfast1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("snack1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dinner1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dessert1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("other1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}
function snackSelect(){
    var rd = document.getElementById("breakfast1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("snack1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("dinner1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dessert1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("other1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}
function dinnerSelect(){
    var rd = document.getElementById("breakfast1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("snack1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dinner1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("dessert1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("other1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}
function dessertSelect(){
    var rd = document.getElementById("breakfast1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("snack1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dinner1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dessert1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("other1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}
function otherSelect(){
    var rd = document.getElementById("breakfast1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("snack1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dinner1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("dessert1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
    var rd = document.getElementById("other1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
}
function minutesSelect(){
    var rd = document.getElementById("minutes1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("hours1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}
function hoursSelect(){
    var rd = document.getElementById("hours1");
    rd.style.backgroundColor ="rgba(255, 255, 255, 0.479)";
    var rd = document.getElementById("minutes1");
    rd.style.backgroundColor ="rgba(0, 0, 0, 0.0)";
}